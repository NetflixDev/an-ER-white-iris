
/* an-ER-white-iris:586328cd-b233-4e42-8cfa-2bc84180a86f.js, VERSION: 5.0.0, Published: 2019/04/09 11:13:39 $*/
// GENERIC SOURCE TRACKER: an-ER-fade-in
if (typeof module === 'undefined') {
  module = {};
}
// prettier-ignore
module.exports = {
	"id": "586328cd-b233-4e42-8cfa-2bc84180a86f",
	"name": "an-ER-white-iris",
	"description": "White iris wipe",
	"type": "animations",
	"context": "Default",
	"state": "published",
	"updated": 1551293070825,
	"full_name": "NetflixDev/an-ER-white-iris",
	"html_url": "https://github.com/NetflixDev/an-ER-white-iris",
	"username": "GitHub",
	"version": "5.0.0",
	"minimum": "3.0.0"
}
